package com.zensar;

public class Bike implements Vehicle{

	
	 public void drive() {
		 System.out.println("Bike running fast");
	 }
}
