package com.zensar;

public class Car implements Vehicle  {
   public void drive() {
	   System.out.println("Car is running");
   }
}
