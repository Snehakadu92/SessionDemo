package com.zensar;

public class Truck implements Vehicle {
    public void drive() {
        System.out.println("Truck is going speedly");
    }
}
