package com.zensar;

public interface Vehicle {
     void drive();
     
}
